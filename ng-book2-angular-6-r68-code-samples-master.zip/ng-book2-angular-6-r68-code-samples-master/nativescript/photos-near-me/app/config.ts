export const Config = {
    Flickr: {
        CLIENT_ID: "b8241dc9b98813054de12ebfc7784321",
        API_URL: "https://api.flickr.com/services/rest/?"
    },
    MapBox: {
        ACCESS_TOKEN: "sk.eyJ1IjoiYnVya2Vob2xsYW5kIiwiYSI6ImNpcXh3NXd3NDAxcDJmbG04M2FxNW5zc3YifQ.kVNHOX6UvgsTPS4BJebtLg"
    }
};